/********************************************************************************
*  WEB322 – Assignment 02
* 
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
* 
*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
* 
*  Name: SM Tausif. Student ID: 187699236. Date: 05.10.24
*
********************************************************************************/

const express = require('express');
const projectData = require('./modules/projects');  // Importing our project data module

const app = express();  // Creating an Express application
const PORT = 3000;  // Defining the port for the server to listen on

// Initialize the project data before starting the server
projectData.Initialize()
    .then(() => {
        // Starting the server after initialization
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });
    })
    .catch((error) => {
        console.error("Failed to initialize project data:", error);
    });

// Route: GET "/"
// This route sends back the student's name and ID
app.get('/', (req, res) => {
    res.send('Assignment 2: Tausif - 187699236');
});

// Route: GET "/solutions/projects"
// This route sends back all projects
app.get('/solutions/projects', (req, res) => {
    projectData.getAllProjects()
        .then((projects) => {
            res.json(projects);  // Respond with the projects array in JSON format
        })
        .catch((error) => {
            res.status(500).send(error);  // Respond with an error if something goes wrong
        });
});

// Route: GET "/solutions/projects/id-demo"
// This route demonstrates getProjectById by returning a project with a known ID
app.get('/solutions/projects/id-demo', (req, res) => {
    const demoProjectId = 9;  // Example known project ID
    projectData.getProjectById(demoProjectId)
        .then((project) => {
            res.json(project);  // Respond with the project object
        })
        .catch((error) => {
            res.status(404).send(error);  // Respond with an error if the project is not found
        });
});

// Route: GET "/solutions/projects/sector-demo"
// This route demonstrates getProjectsBySector by returning projects with a known sector
app.get('/solutions/projects/sector-demo', (req, res) => {
    const demoSector = 'agriculture';  // Example sector (partial and case-insensitive)
    projectData.getProjectsBySector(demoSector)
        .then((projects) => {
            res.json(projects);  // Respond with the array of projects in the sector
        })
        .catch((error) => {
            res.status(404).send(error);  // Respond with an error if no projects are found
        });
});
